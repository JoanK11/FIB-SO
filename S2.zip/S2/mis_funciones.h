// Alumne: Joan Caballero Castro
// Subgrup: 32

#include <stdio.h>
#include <string.h>
#define MAX_SIZE 8

// Devuelve 1 si todos los carácteres de la string str representan números.
// En caso contrario devuelve falso.
int esNumero(char *str);

// Retorna el valor numérico de un carácter que representa un número.
unsigned int char2int(char c);

// Convierte la string con todos sus carácteres representando números a int.
int mi_atoi(char *s);

// Escribe la funcionalidad del programa
void Usage();