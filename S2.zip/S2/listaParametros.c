// Alumne: Joan Caballero Castro
// Subgrup: 32

#include <stdio.h>
#include <string.h>

void Usage() {
	char buf[111];
	sprintf(buf, "Usage:listaParametros arg1 [arg2..argn]\nEste programa escribe por su salida la lista de argumentos que recibe\n");
	write(1, buf, strlen(buf));
}

int main(int argc, char *argv[]) {
	if (argc < 2) Usage();
	else {
		char buf[80];
		for (int i = 0; i < argc; ++i) {
			sprintf(buf, "El argumento %d es %s\n", i, argv[i]);
			write(1, buf, strlen(buf));
		}
	}
	return 0;
}