//Alumne: Joan Caballero Castro
//Subgrup: 32

#include <stdio.h>
#include <string.h>
#define MAX_SIZE 8

int main(int argc,char *argv[]) {
	char buf[80];
	int r = esNumero(argv[1]);

	if (r)
		sprintf(buf, "Es número\n");
	else
		sprintf(buf, "No es número\n");

	write(1, buf, strlen(buf));
	return 0;
}