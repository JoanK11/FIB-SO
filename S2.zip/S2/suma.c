// Alumne: Joan Caballero Castro
// Subgrup: 32

#include <stdio.h>
#include <string.h>
#include "mis_funciones.h"

int main(int argc, char *argv[]) {
	if (argc < 3) Usage();
		else {
		char buf[80];
		int total = 0, b = 1;
		
		for (int i = 1; i < argc && b; ++i) {
			b = esNumero(argv[i]);
			if (b) total += mi_atoi(argv[i]);
		}
		
		if (b) {
			sprintf(buf, "La suma es %d\n", total);
			write(1, buf, strlen(buf));
		}
	}
	return 0;
}