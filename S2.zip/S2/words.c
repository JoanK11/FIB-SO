// Alumne: Joan Caballero Castro
// Subgrup: 32

#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
  char buff[110];
  if (argc == 1)
    sprintf(buff, "Usage: words arg1\nEste programa escribe por su salida el número de palabras de su primer parámetro\n");
  else {
    int x = 1;
    for (int i = 1; i < strlen(argv[1]); ++i) {
      if (argv[1][i] == ' ' || argv[1][i] == '.' || argv[1][i] == ',' || argv[1][i] == '\n') ++x;
    }
    sprintf(buff, "%d palabras\n", x);
  }
  write(1, buff, strlen(buff));
  return 0;
}