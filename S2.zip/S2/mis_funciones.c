// Alumne: Joan Caballero Castro
// Subgrup: 32

#include "mis_funciones.h"

int esNumero(char *str) {
	if (str == NULL) return 0;
	if (str[0] == '-') ++str;
	
	int i;
	for (i = 0; str[i] != '\0' && i <= MAX_SIZE; ++i) {
		if (str[i] < '0' || str[i] > '9') {
			char buf[80];
			sprintf(buf, "Error: el parámetro “%c” no es un número\n", str[i]);
			write(1, buf, strlen(buf));
			return 0;
		}
	}
	return i > 0 && i <= MAX_SIZE;
}

unsigned int char2int(char c) {
	return c - '0';
}

int mi_atoi(char *s) {
	int i = 0, mult = 1;
	if (s[0] == '-') mult = -1, ++i;
	
	int total = 0;
	for (; s[i] != '\0'; ++i) {
		total *= 10;
		total += char2int(s[i]);
	}
	return total*mult;
}

void Usage() {
	char buf[120];
	sprintf(buf, "Usage:listaParametros arg1 arg2 [arg3..argn]\nEste programa escribe por su salida la lista de argumentos que recibe\n");
	write(1, buf, strlen(buf));
}