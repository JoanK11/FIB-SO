#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>

void error_y_exit(char *msg, int exit_status) {
  perror(msg);
  exit(exit_status);
}

int main(int argc, char *argv[]) {
  int pids[11];
  char buff[30];
  for (int i = 1; i < argc; ++i) {
    pids[i] = fork();
    if (pids[i] == 0) {
      sprintf(buff, "/proc/%s/status", argv[i]);
      if (execlp("grep", "grep", "State", buff, NULL) < 0)
        error_y_exit("Error en el execlp", 1);
    }
    else if (pids[i] == -1) error_y_exit("Error en el fork", 1);
  }
  int wstatus, pid;
  while ((pid = waitpid(-1, &wstatus, 0)) > 0) {
    if (WIFEXITED(wstatus) && WEXITSTATUS(wstatus) != 0) {
      int i = 0;
      while (pids[++i] != pid);
      sprintf(buff, "Proceso %s no existe\n", argv[i]);
      write(1, buff, strlen(buff));
      exit(0);
    }
  }
  exit(0);
}