#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <signal.h>

void Usage() {
	char buff[120];
	sprintf(buff, "Usage:signals arg1\n");
	write(1, buff, strlen(buff));
  exit(0);
}

void error_y_exit(char *msg, int exit_status) {
  perror(msg);
  exit(exit_status);
}

int pid_padre;

void signal_y_exit(int s) {
  kill(pid_padre, SIGUSR1);
  exit(0);
}

void nothing(int s) { return; }

int main(int argc, char *argv[]) {
  // 
  if (argc != 2) Usage();
  
  // 
  sigset_t mask;
  sigemptyset(&mask);
  sigaddset(&mask, SIGUSR1);
  sigprocmask(SIG_BLOCK, &mask, NULL);
  struct sigaction sa;
  sa.sa_handler = &nothing;
  sigaction(SIGUSR1, &sa, NULL);
  // 
  pid_padre = getpid();
  
  int N = atoi(argv[1]);
  for (int i = 0; i < N; ++i) {
    int pid = fork();
    
    if (pid == 0) {
      char buff[80];
      sprintf(buff, "Soy el hijo %d con PID %d\n", i + 1, getpid());
      write(1, buff, strlen(buff));
      
      sa.sa_handler = &signal_y_exit;
      sigaction(SIGALRM, &sa, NULL);
      alarm(1);
      while(1);
    }
    else if (pid > 0) {
      sigfillset(&mask);
      sigdelset(&mask, SIGUSR1);
      sigdelset(&mask, SIGINT);
      sigsuspend(&mask);
    }
    else error_y_exit("Error en el fork", 1);
  }
  exit(0);
}