#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

void error_y_exit(char *msg, int exit_status) {
  perror(msg);
  exit(exit_status);
}

int main(int argc, char *argv[]) {
  for (int i = 1; i < argc; ++i) {
    int pid = fork();
    if (pid == 0) {
      char buff[30];
      sprintf(buff, "/proc/%s/status", argv[i]);
      if (execlp("grep", "grep", "State", buff, NULL) < 0)
        error_y_exit("Error en el execlp", 1);
    }
    else if (pid == -1) error_y_exit("Error en el fork", 1);
  }
  exit(0);
}