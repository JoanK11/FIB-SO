#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/wait.h>

void error_y_exit(char *msg, int exit_status) {
  perror(msg);
  exit(exit_status);
}

void Usage() {
	char buf[120];
	sprintf(buf, "Usage:grep_test arg1 arg2\n");
	write(1, buf, strlen(buf));
  exit(1);
}

int main(int argc, char *argv[]) {
  if (argc != 3) Usage();
  int pid = fork();
  if (pid == 0) {
    if (execlp("grep", "grep", argv[1], argv[2], NULL) < 0)
      error_y_exit("Error en el execlp\n", 2);
  }
  else if (pid == -1) error_y_exit("Error en el fork\n", 2);
  
  int wstatus;
  char buff[80];
  waitpid(-1, &wstatus, 0);
  if (WEXITSTATUS(wstatus) == 0) {
    sprintf(buff, "La palabra %s esta en el fichero %s\n", argv[1], argv[2]);
  }
  else {
    sprintf(buff, "La palabra %s no esta en el fichero %s\n", argv[1], argv[2]);
  }
  write(1, buff, strlen(buff));
  exit(0);
}

