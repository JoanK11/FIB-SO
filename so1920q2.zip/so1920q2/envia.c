#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>

void fpipe(int s) {
  char buff[20];
  if (s == SIGINT) sprintf(buff, "Soy SIGINT\n");
  else if (s == SIGUSR1) sprintf(buff, "Soy SIGUSR\n");
  write(1, buff, strlen(buff));
}

int main(int argc, char *argv[]) {
  // Configuramos el signal
  struct sigaction sa;
  sa.sa_handler = &fpipe;
  sa.sa_flags = SA_RESTART;
  sigaction(SIGUSR1, &sa, NULL);
  sigaction(SIGINT, &sa, NULL);
  // Configuramos la máscara
  sigset_t mask;
  sigfillset(&mask);
  sigdelset(&mask, SIGUSR1);
  sigdelset(&mask, SIGINT);
  sigprocmask(SIG_BLOCK, &mask, NULL);
  while(1);
}