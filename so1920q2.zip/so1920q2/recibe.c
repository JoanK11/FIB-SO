#include <stdlib.h>

int main(int argc, char *argv[]) {
  int n = atoi(argv[1]);
  if (n == 0) exit(0);
  
}