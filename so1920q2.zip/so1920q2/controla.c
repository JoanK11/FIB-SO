#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>

void error_y_exit(char *msg, int exit_code) {
  perror(msg);
  exit(exit_code);
}

void Usage() {
  char buff[80];
  sprintf(buff, "Usage: controla arg1 arg2\n");
  write(1, buff, strlen(buff));
  exit(1);
}

int time = 0;

void signals(int s) {
  if (s == SIGALRM) {
    ++time;
  }
  else if (s == SIGUSR1) {
    char buff[80];
    sprintf(buff, "Llevamos %d segundos.\n", time);
    write(1, buff, strlen(buff));
  }
  else if (s == SIGCHLD) {
    char buff[80];
    sprintf(buff, "Hemos recibido un SIGCHLD.\n");
    write(1, buff, strlen(buff));
    exit(0);
  }
}

int main(int argc, char *argv[]) {
  if (argc != 3) Usage();

  // Bloqueamos los signals
  sigset_t mask;
  sigfillset(&mask);
  sigdelset(&mask, SIGALRM), sigdelset(&mask, SIGUSR1), sigdelset(&mask, SIGCHLD);
  if (sigprocmask(SIG_SETMASK, &mask, NULL) < 0) error_y_exit("Error en el sigprocmask.\n", 2);

  // Cambiamos las acciones de los signals
  struct sigaction sa;
  sa.sa_flags = SA_RESTART;
  sa.sa_handler = &signals;
  sigaction(SIGALRM, &sa, NULL), sigaction(SIGUSR1, &sa, NULL), sigaction(SIGCHLD, &sa, NULL);

  int n = atoi(argv[1]);
  int pid = fork();
  if (pid == 0) {
    char buff[80];
    sprintf(buff, "./%s", argv[2]);
    execlp(buff, argv[2], NULL);
    error_y_exit("Error en el execlp.\n", 2);
  }
  else error_y_exit("Error en el fork.\n", 2);

  while (time < n) {
    alarm(1);
    sigsuspend(&mask);
  }
  kill(pid, SIGKILL);
  char buff[80];
  sprintf(buff, "Se ha acabado el tiempo y hemos matado al proceso hijo.\n");
  write(1, buff, strlen(buff));
  exit(0);
}
