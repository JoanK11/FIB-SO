#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

void error_y_exit(char *msg, int exit_code) {
  perror(msg);
  exit(exit_code);
}

void Usage() {
  char buff[80];
  sprintf(buff, "Usage: suma arg1 arg2\n");
  write(1, buff, strlen(buff));
  exit(1);
}

int main(int argc, char *argv[]) {
  if (argc != 3) Usage();

  int fd0 = open(argv[1], O_RDONLY);
  if (fd0 == -1) error_y_exit("Error en el primer open.\n", 2);

  int sum = 0, ret, i = 0, x;
  char c[4];
  while ((ret = read(fd0, &x, sizeof(int))) > 0) {
    sum += x;
    printf("%d: Hemos leído %d bytes, x = %d y sum = %d.\n", i, ret, x, sum);
  }
  close(fd0);
  if (ret == -1) error_y_exit("Error en el read.\n", 2);

  if (ret) printf("He leído %d numeros.\n", 10/ret);

  char buff[80];
  sprintf(buff, "La suma es %d.\n", sum);
  int fd1 = open(argv[2], O_RDWR | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR | S_IRGRP);
  write(fd1, buff, strlen(buff));
  close(fd0); close(fd1);
  exit(0);
}
