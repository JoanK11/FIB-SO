#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

void error_y_exit(char *msg, int exit_code) {
  perror(msg);
  exit(exit_code);
}

void Usage() {
  char buff[80];
  //sprintf(buff, "Usage: suma_pares arg1 arg2\n");
  write(1, buff, strlen(buff));
  exit(1);
}

int main(int argc, char *argv[]) {

}
