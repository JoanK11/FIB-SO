#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>

void error_y_exit(char *msg, int exit_status) {
  perror(msg);
  exit(exit_status);
}

void Usage() {
  char buff[80];
  sprintf(buff, "Usage: hermano arg1\n");
  write(1, buff, strlen(buff));
  exit(1);
}

int main(int argc, char *argv[]) {
  if (argc != 2) Usage();
  int n = atoi(argv[1]) + 1;
  int pids[n];
  pids[0] = getpid();
  
  for (int i = 1; i < n; ++i) {
    if ((pids[i] = fork()) < 0) error_y_exit("Error en el fork\n", 1);
    
    if (pids[i] == 0) {
      char buff[80];
      sprintf(buff, "Soy el hijo %d con PID %d y mi hermano mayor es %d\n", i, getpid(), pids[i - 1]);
      write(1, buff, strlen(buff));
      exit(0);
    }
  }
  sigset_t mask;
  sigfillset(&mask);
  if (sigprocmask(SIG_BLOCK, &mask, NULL) < 0) error_y_exit("Error en el sigprocmask\n", 1);
  while (waitpid(-1, NULL, 0) != 0);
  exit(0);
}