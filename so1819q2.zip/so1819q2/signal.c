#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>

void error_y_exit(char *msg, int exit_status) {
  write(2, msg, strlen(msg));
  exit(exit_status);
}

void Usage() {
  char buff[80];
  sprintf(buff, "Usage: signal arg1\n");
  write(1, buff, strlen(buff));
  exit(1);
}

int pid;

void alarma(int s) {
  char buff[100];
  if (kill(pid, SIGUSR1) < 0) {
    sprintf(buff, "Proceso %d - Error en el kill: No existía un proceso con PID %d\n", getpid(), pid);
    error_y_exit(buff, 1);
  }
  sprintf(buff, "Proceso %d - He enviado un SIGUSR1 al proceso %d\n", getpid(), pid);
  write(1, buff, strlen(buff));
}

int main (int argc, char *argv[]) {
  if (argc != 2) Usage();
  pid = atoi(argv[1]);
  
  // Configuramos la máscara
  sigset_t mask;
  sigfillset(&mask);
  sigdelset(&mask, SIGALRM);
  // Configuramos la alarma
  struct sigaction sa;
  sa.sa_handler = &alarma;
  sa.sa_flags = SA_RESTART;
  sigfillset(&sa.sa_mask);
  
  if (sigaction(SIGALRM, &sa, NULL) < 0) error_y_exit("Error en el sigaction\n", 1);
  alarm(1);
  sigsuspend(&mask);
  exit(0);
}