#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>

void error_y_exit(char *msg, int exit_status) {
  write(2, msg, strlen(msg));
  exit(exit_status);
}

void Usage() {
  char buff[80];
  sprintf(buff, "Usage: hermano3 arg1\n");
  write(1, buff, strlen(buff));
  exit(1);
}

int main(int argc, char *argv[]) {
  if (argc != 2) Usage();
  int n = atoi(argv[1]) + 1;
  int *pids = malloc(n);
  pids[0] = getpid();
  
  for (int i = 1; i < n; ++i) {
    if ((pids[i] = fork()) < 0) error_y_exit("Error en el fork\n", 1);
    
    if (pids[i] == 0) {
      char buff[80];
      sprintf(buff, "Soy el hijo %d con PID %d y mi hermano mayor es %d\n", i, getpid(), pids[i - 1]);
      write(1, buff, strlen(buff));
      
      char pid[10];
      sprintf(pid, "%d", pids[i - 1]);
      if (execlp("./signal", "signal", pid, NULL) < 0)
        error_y_exit("Error en el execlp\n", 1);
      
    }
  }
  sigset_t mask;
  sigfillset(&mask);
  if (sigprocmask(SIG_BLOCK, &mask, NULL) < 0) error_y_exit("Error en el sigprocmask\n", 1);
  
  int wstatus, pid;
  while ((pid = waitpid(-1, &wstatus, 0)) > 0) {
    char buff[80];
    if (WIFEXITED(wstatus))
      sprintf(buff, "El hijo %d ha muerto por exit\n", pid);
    else
      sprintf(buff, "El hijo %d ha muerto por signal\n", pid);
    write(1, buff, strlen(buff));
  }
  free(pids);
  exit(0);
}