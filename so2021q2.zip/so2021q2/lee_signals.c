#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

void error_y_exit(char *msg, int exit_code) {
  perror(msg);
  exit(exit_code);
}

void Usage() {
  char buff[80];
  sprintf(buff, "Usage: lee_signals arg1\n");
  write(1, buff, strlen(buff));
  exit(1);
}

void ret(int s) { return; }

int main(int argc, char* argv[]) {
  if (argc != 2) Usage();

  int fd0 = open(argv[1], O_RDONLY);
  if (fd0 == -1) error_y_exit("Error en el open fd0.\n", 2);
  int fd1 = open("mis_eventos", O_WRONLY);
  if (fd1 == -1) error_y_exit("Error en el open fd1.\n", 2);
  int n = lseek(fd0, 0, SEEK_END);

  struct sigaction sa;
  sa.sa_handler = &ret;
  sa.sa_flags = SA_RESTART;
  if (sigaction(SIGALRM, &sa, NULL) < 0) error_y_exit("Error en el sigaction.\n", 2);

  sigset_t mask;
  sigfillset(&mask);
  sigdelset(&mask, SIGALRM), sigdelset(&mask, SIGINT);

  for (int i = 0; i < n; i += 2) {
    alarm(5);
    sigsuspend(&mask);
    int pid, exit_code;
    read(fd0, &pid, sizeof(int)), read(fd0, &exit_code, sizeof(int));
    char spid[10], sexit_code[10];
    int len1 = sprintf(spid, "%d", pid);
    int len2 = sprintf(sexit_code, "%d", exit_code);
    write(fd1, &spid, len1), write(fd1, &sexit_code, len2);
    char buff[80];
    sprintf(buff, "El proceso con PID %s ha terminado con estado %s.\n", spid, sexit_code);
    write(1, &buff, strlen(buff));
  }

  close(fd0); close(fd1);
  exit(0);
}
