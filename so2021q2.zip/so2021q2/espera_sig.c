#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>

void error_y_exit(char* msg, int exit_code) {
  perror(msg);
  exit(exit_code);
}

void Usage() {
  char buff[80];
  sprintf(buff, "Usage: espera_sig.\n");
  write(1, buff, strlen(buff));
  exit(1);
}

void f(int s) {
  char buff[80];
  int exit_code;
  switch(s) {
    case SIGINT:  exit_code = 1;
                  sprintf(buff, "%d: He recibido el signal SIGINT y salgo con un %d.\n", getpid(), exit_code);
                  break;
    case SIGUSR1: exit_code = 2;
                  sprintf(buff, "%d: He recibido el signal SIGUSR1 y salgo con un %d.\n", getpid(), exit_code);
                  break;
    case SIGUSR2: exit_code = 3;
                  sprintf(buff, "%d: He recibido el signal SIGUSR2 y salgo con un %d.\n", getpid(), exit_code);
                  break;
  }
  write(2, buff, strlen(buff));
  exit(exit_code);
}

int main(int argc, char* argv[]) {
  // Bloqueamos los signals
  sigset_t mask;
  sigfillset(&mask);
  sigdelset(&mask, SIGINT), sigdelset(&mask, SIGUSR1), sigdelset(&mask, SIGUSR2);
  if (sigprocmask(SIG_SETMASK, &mask, NULL) < 0) error_y_exit("Error en el sigprocmask.\n", 2);

  // Cambiamos sus acciones
  struct sigaction sa;
  sa.sa_handler = &f;
  sa.sa_flags = SA_RESTART;
  if (sigaction(SIGINT, &sa, NULL) < 0) error_y_exit("Error en el sigaction del SIGINT.\n", 2);
  if (sigaction(SIGUSR1, &sa, NULL) < 0) error_y_exit("Error en el sigaction del SIGUSR1.\n", 2);
  if (sigaction(SIGUSR2, &sa, NULL) < 0) error_y_exit("Error en el sigaction del SIGUSR2.\n", 2);
  sigsuspend(&mask);
  exit(0);
}
