#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

void error_y_exit(char *msg, int exit_code) {
  perror(msg);
  exit(exit_code);
}

void Usage() {
  char buff[80];
  sprintf(buff, "Usage: n_espera_sig arg1.\n");
  write(1, buff, strlen(buff));
  exit(1);
}

int* pids;

int main(int argc, char *argv[]) {
  if (argc != 2) Usage();

  int n = atoi(argv[1]);
  pids = malloc(n*sizeof(int));
  if (pids == NULL) error_y_exit("Error en el malloc.\n", 2);

  for (int i = 0; i < n; ++i) {
    pids[i] = fork();
    if (pids[i] == 0) {
      char buff[80];
      sprintf(buff, "Soy el hijo %d y mi PID es %d.\n", i+1, getpid());
      write(1, buff, strlen(buff));
      execlp("./espera_sig", "espera_sig", NULL);
      error_y_exit("Error en el execlp.\n", 2);
    }
    else if (pids[i] == -1) error_y_exit("Error en el fork.\n", 2);
  }

  int fd = open("exit_status.int", O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR | S_IRGRP);
  if (fd == -1) error_y_exit("Error en el open.\n", 2);

  int pid, wstatus;
  while ((pid = waitpid(-1, &wstatus, 0)) > 0) {
    if (WIFEXITED(wstatus)) {
      int exit_code = WEXITSTATUS(wstatus);
      int pos, found = 0;
      for (int i = 0; i < n && !found; ++i) {
        if (pids[i] == pid) found = 1, pos = i;
      }
      char buff[80];
      sprintf(buff, "El hijo %d con PID %d ha terminado con estado %d.\n", pos, pid, exit_code);
      write(1, &buff, strlen(buff));
      if (lseek(fd, pos*2, SEEK_SET) == -1) error_y_exit("Error en el lseek.\n", 2);
      write(fd, &pid, sizeof(int)), write(fd, &exit_code, sizeof(int));
    }
  }

  free(pids);
  exit(0);
}
