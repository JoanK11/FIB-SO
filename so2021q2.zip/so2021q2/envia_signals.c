#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int main(int argc, char* argv[]) {
  char buff[80];
  char pid[10], exit_code[10];

  int fd0 = open("mis_eventos", O_RDONLY);
  while (read(fd0, &pid, 1) > 0) {
    read(fd0, &exit_code, 1);
    switch(atoi(exit_code)) {
      case 1: kill(atoi(pid), SIGINT);
      break;
      case 2: kill(atoi(pid), SIGUSR1);
      break;
      case 3: kill(atoi(pid), SIGUSR2);
      break;
    }
    sprintf(buff, "Le envío el signal %s al proceso %s.\n", exit_code, pid);
    write(1, buff, strlen(buff));
  }

  close(fd0);
  exit(0);
}
