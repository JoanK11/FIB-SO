#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

void error_y_exit(char* msg, int error_status) {
	perror(msg);
	exit(error_status);
}

int main(int argc, char *argv[]) {
  int f;
  f = creat("salida.txt", O_CREAT | O_TRUNC | S_IRUSR | S_IWUSR);
  if (f == -1) error_y_exit("Error en el creat\n", 1);
  write(f, "ABCD", 4);
}
