#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

void Usage() {
  char buff[64];
  sprintf(buff, "Usage: terminal-bomb arg1\n");
  write(1, buff, strlen(buff));
  exit(0);
}

void error_y_exit(char *msg, int exit_code) {
  perror(msg);
  exit(exit_code);
}

int main(int argc, char *argv[]) {
  int fd0 = open(argv[1], O_RDONLY);
  int fd1 = open(argv[1], O_WRONLY);
  int final = lseek(fd0, 0, SEEK_END);
  lseek(fd1, 1, SEEK_END);
  char c;
  while (read(fd0, &c, 1) > 0 && lseek(fd0, 0, SEEK_CUR) <= final) {
    write(fd1, &c, 1);
  }
  close(fd1); close(fd0);
}
