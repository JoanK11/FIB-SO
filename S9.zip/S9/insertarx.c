#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

void error_y_exit(char* msg, int error_status) {
	perror(msg);
	exit(error_status);
}

int main(int argc, char *argv[]) {
  int fd, ret;
  if ((fd = open("salida.txt", O_RDWR)) < 0) error_y_exit("Error en el open\n", 1);
  lseek(fd, -1, SEEK_END);
  char buff[2];
  ret = read(fd, buff, 1);
  lseek(fd, -1, SEEK_END);
  write(fd, "X", 1);
  write(fd, buff, 2);
}
