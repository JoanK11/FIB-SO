#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

void error_y_exit(char *msg, int exit_code) {
  perror(msg);
  exit(exit_code);
}

void Usage() {
  char buff[80];
  sprintf(buff, "Usage: comm arg1\n");
  write(1, buff, strlen(buff));
  exit(1);
}

int main(int argc, char *argv[]) {
  if (argc != 2) Usage();

  int fd1 = open(argv[1], O_WRONLY);
  if (fd1 == -1) {
    if (mknod(argv[1], S_IFIFO, 0) == -1) error_y_exit("Error en el mknod.\n", 2);
    fd1 = open(argv[1], O_WRONLY);
    if (fd1 == -1) error_y_exit("Error al abrir la pipe.\n", 2);
  }
  int pid = fork();
  if (pid == 0) {
    dup2(0, fd1);
    execlp("date", "date", NULL);
    error_y_exit("Error en el execlp.\n", 2);
  }
  else if (pid == -1) error_y_exit("Error en el fork.\n", 2);
  close(fd1);

  int fd0 = open(argv[1], O_RDONLY);
  int sum = 0, ret;
  char buff[80];
  while ((ret = read(fd0, &buff, 80)) > 0) sum += ret;

  sprintf(buff, "El hijo ha escrito %d carácteres en la pipe.\n", sum);
  write(1, buff, strlen(buff));
  close(fd0);
  exit(0);
}
