#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <signal.h>

void error_y_exit(char *msg, int exit_code) {
  perror(msg);
  exit(exit_code);
}

int main(int argc, char *argv[]) {
  // Bloqueamos los signals
  sigset_t mask;
  sigfillset(&mask);
  sigprocmask(SIG_SETMASK, &mask, NULL);

  int pid = 1;
  for (int i = 1; i <= 5 && pid; ++i) {
    pid = fork();
    if (pid == 0) {
      int pid2 = 1;
      for (int j = 1; j <= i && pid2; ++j) {
        pid2 = fork();
        if (pid2 == -1) error_y_exit("Error en el fork.\n", 2);
      }
    }
    else if (pid == -1) error_y_exit("Error en el fork.\n", 2);
  }

  if (pid) {
    sleep(1);
    int pid2 = fork();
    if (pid2 == 0) {
      char ppid[10]; sprintf(ppid, "%d", getppid());
      execlp("pstree", "pstree", "-c", "-p", &ppid, NULL);
      error_y_exit("Error en el execlp.\n", 2);
    }
    else if (pid2 > 0) {
      waitpid(pid2, NULL, 0);
      sigdelset(&mask, SIGINT);
      sigprocmask(SIG_SETMASK, &mask, NULL);
    }
    else if (pid2 == -1) error_y_exit("Error en el fork.\n", 2);
  }
  sigdelset(&mask, SIGINT);
  sigsuspend(&mask);
  exit(0);
}
