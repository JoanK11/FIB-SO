#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>

void error_y_exit(char *msg, int exit_code) {
  perror(msg);
  exit(exit_code);
}

void Usage() {
  char buff[80];
  sprintf(buff, "Usage: comm arg1\n");
  write(1, buff, strlen(buff));
  exit(1);
}

int main(int argc, char *argv[]) {
  if (argc != 2) Usage();

  int fd0 = open(argv[1], O_RDONLY);
  if (fd0 == -1) {
    if (mknod(argv[1], S_IFIFO | 0640, 0) == -1 && errno != EEXIST) error_y_exit("Error en el mknod.\n", 2);
    fd0 = open(argv[1], O_RDONLY);
    if (fd0 == -1) error_y_exit("Error al abrir la pipe de lectura.\n", 2);
  }
  printf("Hacemos el fork\n");
  int pid = fork();
  if (pid == 0) {
    int fd1 = open(argv[1], O_WRONLY);
    if (fd1 == -1) error_y_exit("Error al abrir la pipe de escritura.\n", 2);
    dup2(fd1, 1);
    close(fd0); close(fd1);
    execlp("date", "date", NULL);
    error_y_exit("Error en el execlp.\n", 2);
  }
  else if (pid == -1) error_y_exit("Error en el fork.\n", 2);

  int sum = 0, ret;
  char c[1];
  while ((ret = read(fd0, &c, 1)) > 0) {
    printf("%s", c);
    sum += ret;
  }
  if (ret == -1) error_y_exit("Error en el read.\n", 2);
  else if (!ret) printf("No hemos leído nada.\n");

  char buff[80];
  sprintf(buff, "El hijo ha escrito %d carácteres en la pipe.\n", sum);
  write(1, buff, strlen(buff));
  close(fd0);
  exit(0);
}
