#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

void error_y_exit(char *msg, int exit_code) {
  perror(msg);
  exit(exit_code);
}

int main(int argc, char *argv[]) {
  int pid = 1;
  for (int i = 1; i <= 5 && pid; ++i) {
    pid = fork();
    if (pid == 0) {
      int pid2 = 1;
      for (int j = 1; j <= i && pid2; ++j) {
        pid2 = fork();
        if (pid2 == -1) error_y_exit("Error en el fork.\n", 2);
      }
    }
    else if (pid == -1) error_y_exit("Error en el fork.\n", 2);
  }

  if (pid) {
    sleep(1);
    int pid2 = fork();
    if (pid2 == 0) {
      char ppid[10]; sprintf(ppid, "%d", getppid());
      execlp("pstree", "pstree", "-c", "-p", &ppid, NULL);
      error_y_exit("Error en el execlp.\n", 2);
    }
    else if (pid2 == -1) error_y_exit("Error en el fork.\n", 2);
  }
  pause();
  exit(0);
}
