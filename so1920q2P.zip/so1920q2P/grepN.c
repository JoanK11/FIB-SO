#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

void error_y_exit(char *msg, int exit_code) {
  perror(msg);
  exit(exit_code);
}

void Usage() {
  char buff[80];
  sprintf(buff, "Usage: grepN arg1 arg2 arg3\n");
  write(1, buff, strlen(buff));
  exit(1);
}

char *buffer;

int main(int argc, char *argv[]) {
  if (argc != 4) Usage();

  int pid = fork();
  if (pid > 0) {
    int wstatus;
    waitpid(-1, &wstatus, 0);
    if (WEXITSTATUS(wstatus) == 2) {
      char buff[80];
      sprintf(buff, "El fichero %s no existe.\n", argv[3]);
      write(2, buff, strlen(buff));
      exit(2);
    }
  }
  else if (!pid) {
    execlp("grep", "grep", "-q", "a", argv[3], NULL);
    error_y_exit("Error en el execlp.\n", 2);
  }
  else if (pid == -1) error_y_exit("Error en el fork.\n", 2);
  int n = atoi(argv[1]);
  char c = *argv[2];

  buffer = malloc(n);

  int fd0 = open(argv[3], O_RDONLY), ret, count = 0;
  while ((ret = read(fd0, buffer, n)) > 0) {
    for (int i = 0; i < ret; ++i) {
      if (buffer[i] == c) ++count;
    }
  }

  char buff[80];
  sprintf(buff, "El carácter %s sale %d veces en el fichero %s.\n", argv[2], count, argv[3]);
  write(1, buff, strlen(buff));

  free(buffer);
  exit(0);
}
