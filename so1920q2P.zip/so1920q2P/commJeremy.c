#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include<errno.h>
void error_y_exit(const char* msg, int num){
    perror(msg);
    exit(num);
}
void usage(){
    char buff[80];
    sprintf(buff,"comm [nombre del archivo]\n");
    write(1, buff, strlen(buff));
}
int main(int argc, char* argv[]){
    if(argc != 2) usage();
    else{
        //creamos pipe

        int operacion = mknod(argv[1], S_IFIFO|S_IRWXU, 0);
        if (operacion < 0 && errno != EEXIST)error_y_exit("error en la creacion de la pipe", 1);

       //abrimos pipe en modo de lectura

        //creamos hijo
        int return_value = fork();
        if(return_value<0)error_y_exit("error en la creacion del hijo",1);

        else if (return_value == 0){
            // queremos que escribir en la pipe la fecha
            sleep(3);
            int fd2 = open(argv[1],O_WRONLY|O_TRUNC);
            if(fd2 < 0)error_y_exit("error en la apertura de la pipe",1);
            //duplicamos en la salida estandar la entrada de la pipe
            dup2(fd2, 1);
            //cerramos la salida la entrada inicial de la pipe
            close(fd2);
            if(execlp("date", "date", NULL) < 0) error_y_exit("error en la mutacion", 1);
        }

        int fd = open(argv[1],O_RDONLY);
        if(fd < 0)error_y_exit("error en la apertura de la pipe",1);
        //padre espera al hijo
        waitpid(-1, NULL, 0);

        int numero_de_byte = 0;

        int suma;
        char buff2[80];
        while((suma = read(fd,&buff2, sizeof(buff2)))> 0) numero_de_byte += suma;
        close(fd);
        char buff[80];
        sprintf(buff,"el numero de bytes en la pipe es: %d\n", numero_de_byte);
        write(1, buff, strlen(buff));
        exit(0);


    }
}
