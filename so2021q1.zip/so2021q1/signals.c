#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/wait.h>

void Usage() {
  char buff[80];
  sprintf(buff, "Usage: signals arg\n");
  write(2, buff, strlen(buff));
  exit(0);
}

void error_y_exit(char *msg, int exit_status) {
  write(2, msg, strlen(msg));
  exit(exit_status);
}

void alarma(int s) {
  char buff[80];
  sprintf(buff, "%d: Timeout\n", getpid());
  write(1, buff, strlen(buff));
  exit(0);
}

void acabar(int s) {
  int x = alarm(0);
  exit(x);
}

int main(int argc, char *argv[]) {
  if (argc != 2) Usage();
  int n = atoi(argv[1]);
  int pids[n];
  
  // Bloqueamos todos los signals
  sigset_t mask;
  sigfillset(&mask);
  sigdelset(&mask, SIGINT);
  if (sigprocmask(SIG_BLOCK, &mask, NULL) < 0) error_y_exit("Error en el sigprocmask\n", 1);
  
  for (int i = 0; i < n; ++i) {
    pids[i] = fork();
    if (pids[i] == 0) {
      // Configuramos la máscara
      sigset_t mask2;
      sigfillset(&mask2);
      sigdelset(&mask2, SIGALRM);
      sigdelset(&mask2, SIGUSR1);
      if (sigprocmask(SIG_BLOCK, &mask2, NULL) < 0) error_y_exit("Error en el sigprocmask\n", 1);
      // Configuramos la alarma
      struct sigaction sa;
      sa.sa_handler = &alarma;
      sa.sa_flags = SA_RESTART;
      if (sigaction(SIGALRM, &sa, NULL) < 0) error_y_exit("Error en el sigaction\n", 1);
      sa.sa_handler = &acabar;
      if (sigaction(SIGUSR1, &sa, NULL) < 0) error_y_exit("Error en el sigaction\n", 1);
      alarm(3);
      sigsuspend(&mask2);
    }
    else if (pids[i] == -1) error_y_exit("Error en el fork\n", 1);
  }
  
  for (int i = 0; i < n; ++i) {
    if (pids[i] % 2 == 0) kill(pids[i], SIGUSR1);
  }
  
  int wstatus, pid;
  while ((pid = waitpid(-1, &wstatus, 0)) > 0) {
    char buff[80];
    int seg = WEXITSTATUS(wstatus);
    sprintf(buff, "Hijo %d. Segundos restantes %d\n", pid, seg);
    write(1, buff, strlen(buff));
  }
  exit(0);
}