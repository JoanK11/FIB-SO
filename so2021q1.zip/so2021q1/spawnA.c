#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

void Usage() {
  char buff[80];
  sprintf(buff, "Usage: spanwA arg1\n");
  write(1, buff, strlen(buff));
  exit(1);
}

int main(int argc, char *argv[]) {
  if (argc != 2) Usage();

  int n = atoi(argv[1]);
  for (int i = 0; i < n; ++i) {

  }
}
