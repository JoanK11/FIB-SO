#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/wait.h>

void error_y_exit(char *msg, int exit_status) {
  write(2, msg, strlen(msg));
  exit(exit_status);
}

int main(int argc, char *argv[]) {
  int n = argc - 1;
  int pids[n];
  
  for (int i = 0; i < n; ++i) {
    pids[i] = fork();
    if (pids[i] == 0) {
      if (execlp("touch", "touch", argv[i + 1], NULL) < 0)
        error_y_exit("Error en el execlp\n", 1);
    }
    else if (pids[i] == -1) error_y_exit("Error en el fork\n", 1);
  }
  int pid;
  while ((pid = waitpid(-1, NULL, 0)) > 0) {
    char buff[80];
    int i = -1;
    for (int j = 0; i == -1 && j < n; ++j) {
      if (pids[j] == pid) i = j;
    }
    sprintf(buff, "Fecha %s actualizada por %d\n", argv[i+1], pid);
    write(1, buff, strlen(buff));
  }
  exit(0);
}